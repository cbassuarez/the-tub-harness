//
//  HarnessClient.swift
//  TubCompanion
//
//  Local network client for harness communication.
//  Handles session setup, preference events, audio contributions.
//

import Foundation
import Network
import Combine

class HarnessClient: NSObject, ObservableObject {
    @Published var connectionState: HarnessConnectionState = .disconnected
    @Published var lastVisualOutput: VisualOutput?
    
    var onVisualUpdate: ((VisualOutput) -> Void)?
    
    private var nwConnection: NWConnection?
    private let queue = DispatchQueue(label: "com.cbassuarez.thetub.harness-client")
    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()
    
    override init() {
        super.init()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        decoder.keyDecodingStrategy = .convertFromSnakeCase
    }
    
    func connectToHarness(host: String = "127.0.0.1", port: UInt16 = 9911) {
        queue.async { [weak self] in
            guard let self = self else { return }
            
            guard let ipv4 = IPv4Address(host) else {
                DispatchQueue.main.async {
                    self.connectionState = .error("Invalid host address")
                }
                return
            }
            
            let endpoint = NWEndpoint.hostPort(host: .ipv4(ipv4), port: NWEndpoint.Port(rawValue: port) ?? 9911)
            let params = NWParameters.tcp
            
            let connection = NWConnection(to: endpoint, using: params)
            self.nwConnection = connection
            
            connection.stateUpdateHandler = { [weak self] state in
                DispatchQueue.main.async {
                    switch state {
                    case .ready:
                        self?.connectionState = .connected
                        self?.startReceivingData()
                    case .failed(_):
                        self?.connectionState = .error("Connection failed")
                    case .waiting(_):
                        self?.connectionState = .connecting
                    default:
                        break
                    }
                }
            }
            
            connection.start(queue: self.queue)
        }
    }
    
    func sendPreferenceEvent(_ event: AudiencePreferenceEvent) {
        queue.async { [weak self] in
            guard let self = self, let connection = self.nwConnection else { return }
            
            do {
                let data = try self.encoder.encode(event)
                connection.send(content: data, completion: .contentProcessed { error in
                    if let error = error {
                        DispatchQueue.main.async {
                            self.connectionState = .error(error.localizedDescription)
                        }
                    }
                })
            } catch {
                DispatchQueue.main.async {
                    self.connectionState = .error("Encoding failed: \(error)")
                }
            }
        }
    }
    
    func uploadAudioContribution(_ contribution: AudienceAudioContribution) {
        queue.async { [weak self] in
            guard let self = self, let connection = self.nwConnection else { return }
            
            do {
                let data = try self.encoder.encode(contribution)
                connection.send(content: data, completion: .contentProcessed { error in
                    if error == nil {
                        DispatchQueue.main.async {
                            // Notify success
                        }
                    }
                })
            } catch {
                DispatchQueue.main.async {
                    self.connectionState = .error("Upload failed: \(error)")
                }
            }
        }
    }
    
    func fetchQueuedContributions(completion: @escaping ([AudienceAudioContribution]) -> Void) {
        // Stub: in real impl, would query harness
        completion([])
    }
    
    private func startReceivingData() {
        queue.async { [weak self] in
            guard let self = self else { return }
            self.receiveMessage()
        }
    }
    
    private func receiveMessage() {
        guard let connection = nwConnection else { return }
        
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let self = self else { return }
            
            if let data = data {
                do {
                    let visual: VisualOutput = try self.decoder.decode(VisualOutput.self, from: data)
                    DispatchQueue.main.async {
                        self.lastVisualOutput = visual
                        self.onVisualUpdate?(visual)
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.connectionState = .error("Decoding failed: \(error)")
                    }
                }
            }
            
            if !isComplete && error == nil {
                self.receiveMessage()
            }
        }
    }
    
    func disconnect() {
        nwConnection?.cancel()
        nwConnection = nil
        DispatchQueue.main.async {
            self.connectionState = .disconnected
        }
    }
}

