//
//  FieldView.swift
//  TubCompanion
//
//  Main preference steering surface.
//  Drag toward descriptors, hold, more/less, pairwise compare.
//  No mode disclosure.
//

import SwiftUI

struct FieldView: View {
    @ObservedObject var appState: TubCompanionAppState
    let harnessClient: HarnessClient
    
    @State private var selectedDescriptors: Set<String> = []
    @State private var dragPosition: CGPoint = .zero
    @State private var isHolding = false
    @State private var holdDuration: Double = 0.0
    @State private var liveVisuals: VisualFeedbackRep?
    
    var body: some View {
        ZStack {
            Color(UIColor(named: "DarkBackground") ?? .black)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("FIELD")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundColor(.gray)
                        Text("Shape The Sound")
                            .font(.system(size: 14, weight: .semibold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        Text(appState.harnessConnectionState == .connected ? "LIVE" : "OFFLINE")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(appState.harnessConnectionState == .connected ? Color(UIColor(named: "GlyphGreen") ?? .green) : .red)
                    }
                }
                .padding(16)
                .borderBottom(color: Color.white.opacity(0.1))
                
                // Main interaction area
                VStack(spacing: 20) {
                    // Live visual feedback
                    if let visual = liveVisuals {
                        VisualFeedbackDisplay(representation: visual)
                            .frame(height: 120)
                    }
                    
                    // Descriptor field (draggable)
                    DescriptorGridView(
                        selectedDescriptors: $selectedDescriptors,
                        dragPosition: $dragPosition,
                        isHolding: $isHolding,
                        onDragToward: { descriptor, intensity in
                            sendPreferenceEvent(.dragTowardDescriptor, descriptor: descriptor, intensity: intensity)
                        },
                        onHold: {
                            sendPreferenceEvent(.hold, intensity: 1.0)
                        },
                        onRelease: {
                            sendPreferenceEvent(.release, intensity: holdDuration)
                        }
                    )
                    
                    // Action buttons
                    HStack(spacing: 12) {
                        Button(action: { sendPreferenceEvent(.lessAction, intensity: 1.0) }) {
                            HStack(spacing: 8) {
                                Image(systemName: "minus.circle.fill")
                                Text("Less")
                            }
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(10)
                            .background(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.7))
                            .cornerRadius(4)
                        }
                        
                        Button(action: { sendPreferenceEvent(.moreAction, intensity: 1.0) }) {
                            HStack(spacing: 8) {
                                Image(systemName: "plus.circle.fill")
                                Text("More")
                            }
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(10)
                            .background(Color(UIColor(named: "GlyphGreen") ?? .green))
                            .cornerRadius(4)
                        }
                    }
                    
                    // Status text
                    if selectedDescriptors.count > 0 {
                        Text("→ \(selectedDescriptors.sorted().joined(separator: ", "))")
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                            .lineLimit(2)
                    }
                }
                .padding(16)
                
                Spacer()
            }
        }
        .onAppear {
            setupLiveVisuals()
        }
    }
    
    private func sendPreferenceEvent(_ eventType: PreferenceEventType, descriptor: String? = nil, intensity: Double = 0.5) {
        guard let sessionId = appState.sessionId else { return }
        
        let event = AudiencePreferenceEvent(
            sessionId: sessionId,
            eventType: eventType,
            descriptorLabel: descriptor,
            intensity: intensity,
            position: dragPosition
        )
        
        harnessClient.sendPreferenceEvent(event)
    }
    
    private func setupLiveVisuals() {
        harnessClient.onVisualUpdate = { (visual: VisualOutput) in
            self.liveVisuals = VisualFeedbackRep(from: visual)
        }
    }
}

// MARK: - Visual Feedback

struct VisualFeedbackDisplay: View {
    let representation: VisualFeedbackRep
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(0.02)))
            
            VStack(spacing: 12) {
                Text(representation.sceneLabel)
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundColor(.gray)
                
                HStack(spacing: 8) {
                    Text("density")
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.gray)
                        .frame(width: 40, alignment: .leading)
                    
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            RoundedRectangle(cornerRadius: 2)
                                .fill(Color.white.opacity(0.1))
                            
                            RoundedRectangle(cornerRadius: 2)
                                .fill(Color(UIColor(named: "AberrationCyan") ?? .cyan))
                                .frame(width: geo.size.width * representation.density)
                        }
                    }
                    .frame(height: 4)
                    
                    Text(String(format: "%.2f", representation.density))
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.gray)
                        .frame(width: 35, alignment: .trailing)
                }
                
                Text("thought: \(representation.thought)")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.8))
            }
            .padding(12)
        }
    }
}

// MARK: - Descriptor Grid

struct DescriptorGridView: View {
    @Binding var selectedDescriptors: Set<String>
    @Binding var dragPosition: CGPoint
    @Binding var isHolding: Bool
    
    let onDragToward: (String, Double) -> Void
    let onHold: () -> Void
    let onRelease: () -> Void
    
    @State private var descriptors: [String] = ["bright", "dark", "dense", "sparse", "warm", "cold"]
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Simple grid overlay
                VStack(spacing: 20) {
                    HStack(spacing: 20) {
                        ForEach(descriptors.prefix(3), id: \.self) { descriptor in
                            DescriptorCircle(
                                label: descriptor,
                                isSelected: selectedDescriptors.contains(descriptor),
                                onTap: { selectedDescriptors.toggle(descriptor) }
                            )
                        }
                    }
                    
                    HStack(spacing: 20) {
                        ForEach(descriptors.dropFirst(3).prefix(3), id: \.self) { descriptor in
                            DescriptorCircle(
                                label: descriptor,
                                isSelected: selectedDescriptors.contains(descriptor),
                                onTap: { selectedDescriptors.toggle(descriptor) }
                            )
                        }
                    }
                }
                .padding(16)
            }
            .frame(height: 200)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        dragPosition = value.location
                        if let nearest = descriptors.min(by: { a, b in
                            let distA = hypot(Double(a.hashValue) - value.location.x, 0)
                            let distB = hypot(Double(b.hashValue) - value.location.x, 0)
                            return distA < distB
                        }) {
                            onDragToward(nearest, 0.5)
                        }
                    }
                    .onEnded { _ in
                        dragPosition = .zero
                    }
            )
            .onLongPressGesture(minimumDuration: 0.5, perform: {
                isHolding = true
                onHold()
            }, onPressingChanged: { pressing in
                if !pressing {
                    isHolding = false
                    onRelease()
                }
            })
        }
    }
}

struct DescriptorCircle: View {
    let label: String
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 4) {
                ZStack {
                    Circle()
                        .stroke(isSelected ? Color(UIColor(named: "GlyphGreen") ?? .green) : Color.white.opacity(0.2), lineWidth: 2)
                        .frame(width: 48, height: 48)
                    
                    if isSelected {
                        Circle()
                            .fill(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.2))
                            .frame(width: 48, height: 48)
                    }
                }
                
                Text(label)
                    .font(.system(size: 9, weight: .semibold, design: .monospaced))
                    .foregroundColor(isSelected ? Color(UIColor(named: "GlyphGreen") ?? .green) : .gray)
            }
        }
    }
}

// MARK: - Visual Representation

struct VisualFeedbackRep {
    let sceneLabel: String
    let density: Double
    let thought: String
    let cohesion: Double
    
    init(from visual: VisualOutput) {
        self.sceneLabel = visual.sceneId.uppercased()
        self.density = visual.density
        self.thought = visual.thought.uppercased()
        self.cohesion = visual.cohesion
    }
}

// MARK: - Helpers

extension Set where Element == String {
    mutating func toggle(_ element: String) {
        if contains(element) {
            remove(element)
        } else {
            insert(element)
        }
    }
}

extension View {
    func borderBottom(color: Color, width: CGFloat = 1) -> some View {
        self.overlay(
            VStack {
                Spacer()
                Rectangle()
                    .fill(color)
                    .frame(height: width)
            },
            alignment: .bottom
        )
    }
}
