//
//  SettingsView.swift
//  TubCompanion
//
//  Settings and session management.
//  Includes hidden artist sheet access.
//

import SwiftUI
import Combine

struct SettingsView: View {
    @ObservedObject var appState: TubCompanionAppState
    @State private var showArtistSheet = false
    @State private var artistSheetUnlocked = false
    
    var body: some View {
        ZStack {
            Color(UIColor(named: "DarkBackground") ?? .black).ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("SETTINGS")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundColor(.gray)
                        Text("Configuration")
                            .font(.system(size: 14, weight: .semibold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    Spacer()
                }
                .padding(16)
                .borderBottom(color: Color.white.opacity(0.1))
                
                ScrollView {
                    VStack(spacing: 16) {
                        // Session info
                        VStack(alignment: .leading, spacing: 8) {
                            Text("SESSION")
                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                .foregroundColor(.gray)
                            
                            if let sessionId = appState.sessionId {
                                HStack {
                                    Text("ID: ")
                                        .foregroundColor(.gray)
                                        .font(.system(size: 10, design: .monospaced))
                                    Text(sessionId)
                                        .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                }
                            }
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.03))
                        .cornerRadius(4)
                        
                        // Harness connection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("HARNESS")
                                .font(.system(size: 10, weight: .bold, design: .monospaced))
                                .foregroundColor(.gray)
                            
                            HStack {
                                Text("Status: ")
                                    .foregroundColor(.gray)
                                    .font(.system(size: 10, design: .monospaced))
                                Text(connectionStatusLabel(appState.harnessConnectionState))
                                    .foregroundColor(connectionStatusColor(appState.harnessConnectionState))
                                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                            }
                        }
                        .padding(12)
                        .background(Color.white.opacity(0.03))
                        .cornerRadius(4)
                        
                        // Hidden artist button (easter egg)
                        Button(action: { showArtistSheet = true }) {
                            HStack {
                                Image(systemName: "lock.open")
                                Text("Advanced Controls")
                                Spacer()
                                Image(systemName: "chevron.right")
                            }
                            .font(.system(size: 12, design: .monospaced))
                            .foregroundColor(.gray)
                            .padding(12)
                            .background(Color.white.opacity(0.03))
                            .cornerRadius(4)
                        }
                        
                        Spacer()
                    }
                    .padding(16)
                }
            }
        }
        .sheet(isPresented: $showArtistSheet) {
            ArtistAdvancedSheetView(isPresented: $showArtistSheet)
        }
    }
    
    private func connectionStatusLabel(_ state: HarnessConnectionState) -> String {
        switch state {
        case .disconnected:
            return "Disconnected"
        case .connecting:
            return "Connecting..."
        case .connected:
            return "Connected"
        case .error:
            return "Error"
        }
    }
    
    private func connectionStatusColor(_ state: HarnessConnectionState) -> Color {
        switch state {
        case .connected:
            return Color(UIColor(named: "GlyphGreen") ?? .green)
        case .error:
            return .red
        default:
            return .gray
        }
    }
}

struct ArtistAdvancedSheetView: View {
    @Binding var isPresented: Bool
    @State private var paramBias: Double = 0.0
    @State private var thoughtBiasFactorBias: Double = 0.0
    @State private var audioTendencyBias: Double = 0.0
    
    #if EXHIBITION_MODE
    let artistSheetEnabled = false
    #else
    let artistSheetEnabled = true
    #endif
    
    var body: some View {
        ZStack {
            Color(UIColor(named: "DarkBackground") ?? .black).ignoresSafeArea()
            
            if !artistSheetEnabled {
                VStack {
                    Text("Advanced Controls Disabled")
                        .font(.system(size: 14, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                    Text("(This feature is disabled for this exhibition)")
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundColor(.gray)
                    Button(action: { isPresented = false }) {
                        Text("Close")
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(10)
                            .background(Color(UIColor(named: "GlyphGreen") ?? .green))
                            .cornerRadius(4)
                    }
                    .padding(16)
                }
            } else {
                VStack(spacing: 16) {
                    HStack {
                        Text("ARTIST CONTROLS")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundColor(.gray)
                        Spacer()
                        Button(action: { isPresented = false }) {
                            Image(systemName: "xmark")
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(16)
                    
                    ScrollView {
                        VStack(spacing: 16) {
                            ParameterSliderView(
                                label: "Param Bias",
                                value: $paramBias,
                                range: -0.5...0.5
                            )
                            
                            ParameterSliderView(
                                label: "Thought Bias Factor",
                                value: $thoughtBiasFactorBias,
                                range: -0.5...0.5
                            )
                            
                            ParameterSliderView(
                                label: "Audio Tendency Bias",
                                value: $audioTendencyBias,
                                range: -0.5...0.5
                            )
                            
                            Text("⚠ These controls directly affect the overlay. Changes are bounded and reversible.")
                                .font(.system(size: 9, design: .monospaced))
                                .foregroundColor(.yellow)
                                .padding(8)
                                .background(Color.yellow.opacity(0.1))
                                .cornerRadius(4)
                        }
                        .padding(16)
                    }
                }
            }
        }
    }
}

struct ParameterSliderView: View {
    let label: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(label)
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                Spacer()
                Text(String(format: "%.2f", value))
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
            }
            
            Slider(value: $value, in: range)
                .accentColor(Color(UIColor(named: "GlyphGreen") ?? .green))
        }
        .padding(10)
        .background(Color.white.opacity(0.03))
        .cornerRadius(4)
    }
}
