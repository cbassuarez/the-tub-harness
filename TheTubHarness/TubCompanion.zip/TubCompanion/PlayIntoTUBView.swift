//
//  PlayIntoTUBView.swift
//  TubCompanion
//
//  Audio contribution interface.
//  Cable audio messaging, queue state visualization.
//

import SwiftUI
import Combine

struct PlayIntoTUBView: View {
    @ObservedObject var appState: TubCompanionAppState
    let harnessClient: HarnessClient
    
    @State private var recordingState: RecordingState = .idle
    @State private var queuedContributions: [AudienceAudioContribution] = []
    @State private var selectedContribution: AudienceAudioContribution?
    
    enum RecordingState {
        case idle
        case recording
        case uploading
        case processing
        case complete
    }
    
    var body: some View {
        ZStack {
            Color(UIColor(named: "DarkBackground") ?? .black).ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("PLAY INTO TUB")
                            .font(.system(size: 12, weight: .bold, design: .monospaced))
                            .foregroundColor(.gray)
                        Text("Share Your Sound")
                            .font(.system(size: 14, weight: .semibold, design: .monospaced))
                            .foregroundColor(.white)
                    }
                    Spacer()
                }
                .padding(16)
                .borderBottom(color: Color.white.opacity(0.1))
                
                ScrollView {
                    VStack(spacing: 20) {
                        // Cable info
                        CableStatusView(isConnected: false)
                        
                        // Contribution queue
                        if !queuedContributions.isEmpty {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("QUEUED CONTRIBUTIONS")
                                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                                    .foregroundColor(.gray)
                                
                                ForEach(queuedContributions, id: \.contributionId) { contribution in
                                    ContributionQueueItemView(contribution: contribution)
                                }
                            }
                        } else {
                            VStack(spacing: 12) {
                                Image(systemName: "waveform.circle.fill")
                                    .font(.system(size: 48))
                                    .foregroundColor(.gray.opacity(0.5))
                                Text("No queued contributions yet")
                                    .font(.system(size: 12, design: .monospaced))
                                    .foregroundColor(.gray)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(32)
                        }
                    }
                    .padding(16)
                }
                
                // Record button
                VStack(spacing: 12) {
                    Button(action: toggleRecording) {
                        HStack(spacing: 8) {
                            Image(systemName: recordingState == .recording ? "stop.circle.fill" : "mic.circle.fill")
                            Text(recordingState == .recording ? "Stop Recording" : "Start Recording")
                        }
                        .font(.system(size: 13, weight: .semibold, design: .monospaced))
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(12)
                        .background(recordingState == .recording ? Color.red : Color(UIColor(named: "GlyphGreen") ?? .green))
                        .cornerRadius(4)
                    }
                    .disabled(recordingState == .uploading || recordingState == .processing)
                }
                .padding(16)
            }
        }
        .onAppear { loadQueuedContributions() }
    }
    
    private func toggleRecording() {
        if recordingState == .idle {
            recordingState = .recording
        } else if recordingState == .recording {
            recordingState = .uploading
            uploadRecordedAudio()
        }
    }
    
    private func uploadRecordedAudio() {
        guard let sessionId = appState.sessionId else { return }
        
        let contribution = AudienceAudioContribution(sessionId: sessionId, durationMs: 10000)
        harnessClient.uploadAudioContribution(contribution)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            recordingState = .processing
            queuedContributions.append(contribution)
        }
    }
    
    private func loadQueuedContributions() {
        harnessClient.fetchQueuedContributions { contributions in
            self.queuedContributions = contributions
        }
    }
}

struct CableStatusView: View {
    let isConnected: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text("CABLE AUDIO")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundColor(.gray)
                    Text(isConnected ? "Live Input" : "Not Connected")
                        .font(.system(size: 12, weight: .semibold, design: .monospaced))
                        .foregroundColor(isConnected ? Color(UIColor(named: "GlyphGreen") ?? .green) : .gray)
                }
                Spacer()
                Circle()
                    .fill(isConnected ? Color(UIColor(named: "GlyphGreen") ?? .green) : Color.gray.opacity(0.5))
                    .frame(width: 12, height: 12)
            }
            .padding(12)
            .background(Color.white.opacity(0.05))
            .cornerRadius(4)
            
            if isConnected {
                Text("Your phone audio is flowing directly into the system. Keep the app open to maintain connection.")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(.gray)
            }
        }
    }
}

struct ContributionQueueItemView: View {
    let contribution: AudienceAudioContribution
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(contribution.state.displayName)
                        .font(.system(size: 11, weight: .semibold, design: .monospaced))
                        .foregroundColor(.white)
                    Text(formatDate(contribution.createdAt))
                        .font(.system(size: 9, design: .monospaced))
                        .foregroundColor(.gray)
                }
                Spacer()
                StateIndicator(state: contribution.state)
            }
            
            if let duration = contribution.durationMs {
                Text("\(duration / 1000)s")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.8))
            }
        }
        .padding(10)
        .background(Color.white.opacity(0.03))
        .cornerRadius(4)
        .borderLeft(color: stateColor(contribution.state), width: 2)
    }
    
    private func stateColor(_ state: AudioContributionState) -> Color {
        switch state {
        case .approved:
            return Color(UIColor(named: "GlyphGreen") ?? .green)
        case .rejected:
            return .red
        case .normalizing, .transientSplicing:
            return Color(UIColor(named: "WarningYellow") ?? .yellow)
        default:
            return .gray
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter.string(from: date)
    }
}

struct StateIndicator: View {
    let state: AudioContributionState
    
    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(indicatorColor)
                .frame(width: 6, height: 6)
            Text(state.displayName)
                .font(.system(size: 9, weight: .semibold, design: .monospaced))
                .foregroundColor(indicatorColor)
        }
    }
    
    private var indicatorColor: Color {
        switch state {
        case .approved:
            return Color(UIColor(named: "GlyphGreen") ?? .green)
        case .rejected:
            return .red
        case .normalizing, .transientSplicing:
            return Color(UIColor(named: "WarningYellow") ?? .yellow)
        default:
            return .gray
        }
    }
}

extension View {
    func borderLeft(color: Color, width: CGFloat = 1) -> some View {
        self.overlay(
            VStack {
                Rectangle()
                    .fill(color)
                    .frame(width: width)
                Spacer()
            },
            alignment: .leading
        )
    }
}
