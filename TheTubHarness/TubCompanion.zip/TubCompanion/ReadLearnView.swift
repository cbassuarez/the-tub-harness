//
//  ReadLearnView.swift
//  TubCompanion
//
//  Immersive learning experience with gesture-based navigation.
//  Swipe between full-screen sections—no visible tabs.
//

import SwiftUI

struct ReadLearnView: View {
    let sections = [
        "Quick Start",
        "What is THE TUB",
        "The Gesture Field",
        "Drag to Steer",
        "Hold to Reinforce",
        "More & Less",
        "What We Hear",
        "Send Audio (Cable)",
        "Send Audio (Queue)",
        "Visible Claims",
    ]
    
    var body: some View {
        GeometryReader { proxy in
            let chapterHeight = max(
                proxy.size.height - proxy.safeAreaInsets.top - proxy.safeAreaInsets.bottom - 118,
                560
            )
            let heroHeight = max(chapterHeight * 0.92, 600)

            ScrollView(.vertical, showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ReadLearnHero()
                        .frame(minHeight: heroHeight, alignment: .topLeading)

                    ForEach(Array(sections.enumerated()), id: \.offset) { idx, title in
                        ReadLearnSectionShell(title: title, viewportHeight: chapterHeight) {
                            sectionContent(idx)
                        }
                    }
                }
                .scrollTargetLayout()
                .padding(.horizontal, 18)
                .padding(.top, 8)
                .padding(.bottom, max(proxy.safeAreaInsets.bottom + 132, 150))
            }
            .coordinateSpace(name: "readlearn-scroll")
            .scrollTargetBehavior(.viewAligned(limitBehavior: .always))
            .background(ReadLearnBackground())
        }
    }
    
    @ViewBuilder
    func sectionContent(_ index: Int) -> some View {
        switch index {
        case 0:
            QuickStartView()
        case 1:
            WhatIsTubView()
        case 2:
            GestureFieldView()
        case 3:
            DragGestureAnimation()
        case 4:
            HoldGestureAnimation()
        case 5:
            TapGestureAnimation()
        case 6:
            SpectrumVisualizerView()
        case 7:
            CableAudioView()
        case 8:
            StateMachineView()
        case 9:
            VisibleClaimsView()
        default:
            Text("Unknown Section")
                .foregroundColor(.white)
        }
    }
    // MARK: - Section Views
    
    struct ReadLearnPanelModifier: ViewModifier {
        func body(content: Content) -> some View {
            content
                .padding(.vertical, 10)
                .padding(.horizontal, 12)
                .background(Color.white.opacity(0.015))
                .overlay(
                    Rectangle()
                        .fill(Color.white.opacity(0.08))
                        .frame(height: 1),
                    alignment: .top
                )
                .overlay(
                    Rectangle()
                        .fill(Color.white.opacity(0.04))
                        .frame(height: 1),
                    alignment: .bottom
                )
        }
    }
    struct ReadLearnProgressRail: View {
        let sectionCount: Int
        
        var body: some View {
            VStack(spacing: 8) {
                ForEach(0..<sectionCount, id: \.self) { _ in
                    Capsule()
                        .fill(Color.white.opacity(0.16))
                        .frame(width: 3, height: 18)
                }
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 8)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.black.opacity(0.28))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                    )
            )
        }
    }
    
    struct ReadLearnFooter: View {
        var body: some View {
            VStack(alignment: .leading, spacing: 10) {
                Rectangle()
                    .fill(Color.white.opacity(0.08))
                    .frame(maxWidth: .infinity)
                    .frame(height: 1)
                
                Text("END OF FIELD")
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundColor(.gray)
                    .tracking(1.4)
                
                Text("Return upward at any time. The system remains live.")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.top, 8)
        }
    }
    
    struct ReadLearnSectionShell<Content: View>: View {
        let title: String
        let viewportHeight: CGFloat
        @ViewBuilder var content: Content

        var body: some View {
            VStack(alignment: .leading, spacing: 0) {
                HStack(alignment: .center) {
                    Text(title.uppercased())
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundColor(.gray)
                        .tracking(1.5)

                    Spacer()

                    Rectangle()
                        .fill(Color.white.opacity(0.08))
                        .frame(width: 44, height: 1)
                }

                Spacer(minLength: 20)

                content

                Spacer(minLength: 28)
            }
            .frame(maxWidth: .infinity, minHeight: viewportHeight, alignment: .topLeading)
            .overlay(alignment: .top) {
                Rectangle()
                    .fill(Color.white.opacity(0.06))
                    .frame(height: 1)
            }
            .scrollTransition(axis: .vertical) { view, phase in
                view
                    .opacity(phase.isIdentity ? 1.0 : 0.42)
                    .scaleEffect(phase.isIdentity ? 1.0 : 0.972)
                    .blur(radius: phase.isIdentity ? 0 : 1.2)
                    .offset(y: phase.isIdentity ? 0 : 16)
            }
        }
    }
    
    struct ReadLearnBackground: View {
        var body: some View {
            ZStack {
                Color.black.ignoresSafeArea()
                
                LinearGradient(
                    colors: [
                        Color.black,
                        Color(red: 0.03, green: 0.04, blue: 0.05),
                        Color.black
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                VStack(spacing: 6) {
                    ForEach(0..<90, id: \.self) { _ in
                        Rectangle()
                            .fill(Color.white.opacity(0.018))
                            .frame(height: 1)
                    }
                }
                .blur(radius: 0.2)
                .opacity(0.33)
                .ignoresSafeArea()
                
                Circle()
                    .fill(Color.cyan.opacity(0.06))
                    .frame(width: 260, height: 260)
                    .blur(radius: 60)
                    .offset(x: -120, y: -240)
                
                Circle()
                    .fill(Color.pink.opacity(0.05))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: 130, y: 220)
            }
        }
    }

    
    struct ReadLearnHero: View {
        var body: some View {
            VStack(alignment: .leading, spacing: 18) {
                Spacer(minLength: 8)

                Text("READ / LEARN")
                    .font(.system(size: 44, weight: .bold, design: .monospaced))
                    .foregroundColor(.white)
                    .tracking(0.5)

                Text("Learn enough to participate. Not enough to spoil it.")
                    .font(.system(size: 16, design: .monospaced))
                    .foregroundColor(.gray)
                    .fixedSize(horizontal: false, vertical: true)

                Spacer(minLength: 0)

                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 8) {
                        Image(systemName: "arrow.down")
                            .foregroundColor(.green)
                        Text("Continuous field")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(.gray)
                    }

                    Text("Continue downward.")
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundColor(.gray.opacity(0.9))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }
    
    struct QuickStartView: View {
        var body: some View {
            VStack(alignment: .leading, spacing: 28) {
                Text("30-SECOND INTRO")
                    .font(.system(size: 34, weight: .bold, design: .monospaced))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, alignment: .center)

                VStack(alignment: .leading, spacing: 18) {
                    HStack(spacing: 14) {
                        Image(systemName: "waveform")
                            .foregroundColor(Color(UIColor(named: "AberrationCyan") ?? .cyan))
                        Text("The room is already in the system")
                            .font(.system(size: 13, design: .monospaced))
                            .foregroundColor(.white)
                    }

                    HStack(spacing: 14) {
                        Image(systemName: "hand.draw")
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                        Text("Touch changes the field")
                            .font(.system(size: 13, design: .monospaced))
                            .foregroundColor(.white)
                    }

                    HStack(spacing: 14) {
                        Image(systemName: "mic.fill")
                            .foregroundColor(Color(UIColor(named: "AberrationMagenta") ?? .magenta))
                        Text("Sound can be offered directly")
                            .font(.system(size: 13, design: .monospaced))
                            .foregroundColor(.white)
                    }

                    HStack(spacing: 14) {
                        Image(systemName: "eye")
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                        Text("Participation becomes visible")
                            .font(.system(size: 13, design: .monospaced))
                            .foregroundColor(.white)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Text("Continue downward.")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .center)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
        }
    }
    
    struct WhatIsTubView: View {
        var body: some View {
            VStack(alignment: .leading, spacing: 26) {
                Text("What is THE TUB?")
                    .font(.system(size: 32, weight: .bold, design: .monospaced))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, alignment: .center)

                VStack(alignment: .leading, spacing: 18) {
                    Text("THE TUB is a live environment for sound, attention, and response.")
                        .font(.system(size: 15, design: .monospaced))
                        .foregroundColor(.white)

                    Text("It does not wait for a single performer.")
                        .font(.system(size: 14, design: .monospaced))
                        .foregroundColor(.gray)

                    Text("It changes when contact is made.")
                        .font(.system(size: 14, design: .monospaced))
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: 520, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
        }
    }
    
    struct GestureFieldView: View {
        var body: some View {
            VStack(spacing: 24) {
                Text("The Gesture Field")
                    .font(.system(size: 18, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                
                Text("TOUCH FIELD / LIVE RESPONSE")
                    .font(.system(size: 8, weight: .semibold, design: .monospaced))
                    .foregroundColor(.gray)
                    .tracking(1.2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white.opacity(0.028))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white.opacity(0.12), lineWidth: 1)
                        )
                        .overlay(alignment: .topLeading) {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            Color.white.opacity(0.05),
                                            Color.clear
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .padding(1)
                        }
                    
                    VStack(spacing: 16) {
                        Text("Interactive Zone")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(.gray)
                        
                        VStack {
                            Text("← DRAG TO STEER →")
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                            
                            ZStack {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.white.opacity(0.025))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.white.opacity(0.08), lineWidth: 1)
                                    )
                                    .overlay(alignment: .topLeading) {
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.cyan.opacity(0.16), lineWidth: 1)
                                            .blur(radius: 0.6)
                                            .padding(1)
                                    }
                                    .overlay(alignment: .bottomTrailing) {
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(Color.pink.opacity(0.14), lineWidth: 1)
                                            .blur(radius: 0.6)
                                            .padding(1)
                                    }
                                
                                VStack {
                                    Text("DESCRIPTORS")
                                        .font(.system(size: 8, weight: .semibold, design: .monospaced))
                                        .foregroundColor(.gray)
                                    Spacer()
                                    HStack {
                                        Text("Touch")
                                            .font(.system(size: 9, design: .monospaced))
                                            .foregroundColor(.gray)
                                        Spacer()
                                        Text("Respond")
                                            .font(.system(size: 9, design: .monospaced))
                                            .foregroundColor(.gray)
                                    }
                                    Spacer()
                                }
                                .padding(8)
                            }
                            .frame(height: 80)
                            
                            Text("↑ HOLD TO REINFORCE ↓")
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                .foregroundColor(Color(UIColor(named: "AberrationMagenta") ?? .magenta))
                        }
                    }
                    .padding(16)
                }
                .frame(height: 260)
                
                Text("This is where your touch happens. Drag toward words, hold to reinforce, tap +/− for intensity.")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(.gray)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
        }
    }
    
    
    
    
    
    struct CableAudioView: View {
        var body: some View {
            VStack(spacing: 24) {
                Text("Send Audio (Cable)")
                    .font(.system(size: 32, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                
                VStack(spacing: 12) {
                    Text("Plug in a USB-C to TRS audio cable to send your phone audio directly into the system.")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.white)
                    
                    Text("Your audio becomes part of the live input stream, integrated with everyone else's sound.")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.gray)
                }
                .padding(12)
                .readLearnPanel()
                
                VStack(spacing: 8) {
                    HStack(spacing: 8) {
                        Image(systemName: "app.fill")
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                        Text("Keep the app open while transmitting")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(.gray)
                    }
                    
                    HStack(spacing: 8) {
                        Image(systemName: "hand.tap.fill")
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                        Text("Your touch still works while sending audio")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(.gray)
                    }
                    
                    HStack(spacing: 8) {
                        Image(systemName: "bolt.fill")
                            .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                        Text("Direct, immediate connection to the system")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundColor(.gray)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
        }
    }
    
    struct VisibleClaimsView: View {
        var body: some View {
            VStack(spacing: 24) {
                Text("Visible Claims")
                    .font(.system(size: 18, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white)
                
                VStack(spacing: 12) {
                    Text("When you participate, your presence becomes visible to everyone in the space.")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.white)
                    
                    Text("A reticle or box appears on the main display, showing where you are and that you're engaged.")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundColor(.gray)
                }
                .padding(12)
                .readLearnPanel()
                
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white.opacity(0.028))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white.opacity(0.12), lineWidth: 1)
                        )
                        .overlay(alignment: .topLeading) {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            Color.white.opacity(0.05),
                                            Color.clear
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .padding(1)
                        }
                    
                    VStack(spacing: 16) {
                        Text("ACTIVE PARTICIPANT MARKER")
                            .font(.system(size: 8, weight: .semibold, design: .monospaced))
                            .foregroundColor(.gray)
                            .tracking(1.2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Your Reticle")
                                    .font(.system(size: 11, weight: .semibold, design: .monospaced))
                                    .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                                
                                ZStack {
                                    Rectangle()
                                        .stroke(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.9), lineWidth: 1)
                                        .frame(width: 58, height: 58)
                                    
                                    Rectangle()
                                        .stroke(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.25), lineWidth: 1)
                                        .frame(width: 78, height: 78)
                                    
                                    Circle()
                                        .stroke(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(0.7), lineWidth: 1)
                                        .frame(width: 18, height: 18)
                                    
                                    Rectangle()
                                        .fill(Color(UIColor(named: "GlyphGreen") ?? .green))
                                        .frame(width: 4, height: 4)
                                }
                                .overlay {
                                    Rectangle()
                                        .stroke(Color.cyan.opacity(0.12), lineWidth: 1)
                                        .frame(width: 82, height: 82)
                                        .blur(radius: 0.7)
                                }
                                .overlay {
                                    Rectangle()
                                        .stroke(Color.pink.opacity(0.10), lineWidth: 1)
                                        .frame(width: 62, height: 62)
                                        .blur(radius: 0.7)
                                }
                            }
                            
                            .frame(maxWidth: .infinity, alignment: .leading)
                            
                            Text("Indicates your active presence in the sound field")
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundColor(.gray)
                        }
                    }
                    .frame(height: 170)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                
            }
        }
    }
}

extension View {
    func readLearnPanel() -> some View {
        modifier(ReadLearnView.ReadLearnPanelModifier())
    }
}
