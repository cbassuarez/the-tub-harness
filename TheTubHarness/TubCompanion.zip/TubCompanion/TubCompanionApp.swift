//
//  TubCompanionApp.swift
//  TubCompanion
//
//  Main iOS companion app entry point.
//  Manages session state, harness connection, tab navigation.
//

import SwiftUI
import Combine

@main
struct TubCompanionApp: App {
    @StateObject private var appState = TubCompanionAppState()
    @StateObject private var harnessClient = HarnessClient()
    
    var body: some Scene {
        WindowGroup {
            TabView {
                LaunchView(appState: appState)
                    .tabItem {
                        Label("Launch", systemImage: "antenna.radiowaves.left.and.right")
                    }
                
                FieldView(appState: appState, harnessClient: harnessClient)
                    .tabItem {
                        Label("Field", systemImage: "waveform.circle")
                    }
                
                PlayIntoTUBView(appState: appState, harnessClient: harnessClient)
                    .tabItem {
                        Label("Play", systemImage: "mic.circle")
                    }
                
                ReadLearnView()
                    .tabItem {
                        Label("Learn", systemImage: "book")
                    }
                
                SettingsView(appState: appState)
                    .tabItem {
                        Label("Settings", systemImage: "gear")
                    }
            }
            .environmentObject(appState)
            .environmentObject(harnessClient)
            .onAppear {
                appState.initializeSession()
            }
        }
    }
}

// MARK: - App State

class TubCompanionAppState: NSObject, ObservableObject {
    @Published var sessionId: String?
    @Published var harnessConnectionState: HarnessConnectionState = .disconnected
    @Published var currentDescriptors: [String] = []
    @Published var preferenceEvents: [AudiencePreferenceEvent] = []
    @Published var audioContributions: [AudienceAudioContribution] = []
    
    private let defaults = UserDefaults.standard
    
    override init() {
        super.init()
    }
    
    func initializeSession() {
        if let existingId = defaults.string(forKey: "SessionID") {
            sessionId = existingId
        } else {
            let newId = UUID().uuidString
            sessionId = newId
            defaults.set(newId, forKey: "SessionID")
        }
    }
    
    func recordPreference(_ event: AudiencePreferenceEvent) {
        preferenceEvents.append(event)
    }
    
    func recordContribution(_ contribution: AudienceAudioContribution) {
        audioContributions.append(contribution)
    }
}

