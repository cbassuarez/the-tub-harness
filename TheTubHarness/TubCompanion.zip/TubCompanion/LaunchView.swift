//
//  LaunchView.swift
//  TubCompanion
//
//  Onboarding flow: <15 seconds to field.
//  Cable first, NFC, permissions, harness connection.
//

import SwiftUI

struct LaunchView: View {
    @ObservedObject var appState: TubCompanionAppState
    @State private var currentStep: OnboardingStep = .welcome
    @State private var cableDetected = false
    @State private var audioPermissionGranted = false
    @State private var networkPermissionGranted = false
    
    enum OnboardingStep {
        case welcome
        case cableOrNFC
        case permissions
        case connecting
        case ready
    }
    
    var body: some View {
        ZStack {
            Color(UIColor(named: "DarkBackground") ?? .black)
                .ignoresSafeArea()
            
            VStack(spacing: 24) {
                // Header
                VStack(spacing: 8) {
                    Text("THE TUB")
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                    
                    Text("Audience Entry")
                        .font(.system(size: 11, weight: .regular, design: .monospaced))
                        .foregroundColor(.gray)
                }
                .padding(.top, 32)
                
                Spacer()
                
                // Step-based content
                VStack(spacing: 20) {
                    switch currentStep {
                    case .welcome:
                        welcomeContent
                    case .cableOrNFC:
                        cableOrNFCContent
                    case .permissions:
                        permissionsContent
                    case .connecting:
                        connectingContent
                    case .ready:
                        readyContent
                    }
                }
                
                Spacer()
                
                // Action buttons
                HStack(spacing: 12) {
                    if currentStep != .welcome && currentStep != .ready {
                        Button(action: { goBackStep() }) {
                            Text("Back")
                                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                                .foregroundColor(.gray)
                                .padding(12)
                                .frame(maxWidth: .infinity)
                                .background(Color.white.opacity(0.05))
                                .cornerRadius(4)
                        }
                    }
                    
                    Button(action: { advanceStep() }) {
                        Text(nextButtonLabel)
                            .font(.system(size: 12, weight: .semibold, design: .monospaced))
                            .foregroundColor(.black)
                            .padding(12)
                            .frame(maxWidth: .infinity)
                            .background(Color(UIColor(named: "GlyphGreen") ?? .green))
                            .cornerRadius(4)
                    }
                    .disabled(!canAdvance)
                    .opacity(canAdvance ? 1.0 : 0.5)
                }
                .padding(.bottom, 24)
            }
            .padding(.horizontal, 16)
        }
        .onAppear {
            appState.initializeSession()
        }
    }
    
    // MARK: - Step Views
    
    @ViewBuilder
    var welcomeContent: some View {
        VStack(spacing: 16) {
            Image(systemName: "antenna.radiowaves.left.and.right")
                .font(.system(size: 40))
                .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
            
            Text("Connect to THE TUB")
                .font(.system(size: 16, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
            
            Text("Tap the NFC tag on the cable or enter manually. Less than 15 seconds.")
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .lineLimit(4)
        }
    }
    
    @ViewBuilder
    var cableOrNFCContent: some View {
        VStack(spacing: 16) {
            Text("How are you joining?")
                .font(.system(size: 14, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
            
            VStack(spacing: 8) {
                Text("1. Look for the cable")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Text("2. Tap phone to NFC tag")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Text("3. Or continue manually")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(12)
            .background(Color.white.opacity(0.05))
            .cornerRadius(4)
        }
    }
    
    @ViewBuilder
    var permissionsContent: some View {
        VStack(spacing: 12) {
            Text("Permissions Required")
                .font(.system(size: 14, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
            
            // Microphone
            HStack(spacing: 8) {
                Image(systemName: audioPermissionGranted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 14))
                    .foregroundColor(audioPermissionGranted ? Color(UIColor(named: "GlyphGreen") ?? .green) : .gray)
                
                Text("Microphone")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                
                Spacer()
                
                Button(action: { requestAudioPermission() }) {
                    Text(audioPermissionGranted ? "✓" : "Grant")
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(audioPermissionGranted ? 0.3 : 1.0))
                        .cornerRadius(3)
                }
                .disabled(audioPermissionGranted)
            }
            
            // Local Network
            HStack(spacing: 8) {
                Image(systemName: networkPermissionGranted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 14))
                    .foregroundColor(networkPermissionGranted ? Color(UIColor(named: "GlyphGreen") ?? .green) : .gray)
                
                Text("Local Network")
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                
                Spacer()
                
                Button(action: { requestNetworkPermission() }) {
                    Text(networkPermissionGranted ? "✓" : "Grant")
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundColor(.black)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(UIColor(named: "GlyphGreen") ?? .green).opacity(networkPermissionGranted ? 0.3 : 1.0))
                        .cornerRadius(3)
                }
                .disabled(networkPermissionGranted)
            }
        }
    }
    
    @ViewBuilder
    var connectingContent: some View {
        VStack(spacing: 16) {
            Image(systemName: "network")
                .font(.system(size: 40))
                .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
                .opacity(0.7)
            
            Text("Connecting...")
                .font(.system(size: 14, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
            
            ProgressView()
                .scaleEffect(0.8)
                .tint(Color(UIColor(named: "GlyphGreen") ?? .green))
            
            Text("Finding THE TUB on your network")
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(.gray)
        }
    }
    
    @ViewBuilder
    var readyContent: some View {
        VStack(spacing: 16) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 40))
                .foregroundColor(Color(UIColor(named: "GlyphGreen") ?? .green))
            
            Text("Connected")
                .font(.system(size: 16, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
            
            if let sessionId = appState.sessionId {
                Text("Session: \(sessionId.prefix(8))...")
                    .font(.system(size: 9, design: .monospaced))
                    .foregroundColor(.gray)
            }
            
            Text("Ready to participate in THE TUB")
                .font(.system(size: 11, design: .monospaced))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
        }
    }
    
    // MARK: - State Management
    
    var nextButtonLabel: String {
        switch currentStep {
        case .welcome:
            return "Continue"
        case .cableOrNFC:
            return "I'm Ready"
        case .permissions:
            return "Grant All"
        case .connecting:
            return "Connecting..."
        case .ready:
            return "Enter the Field"
        }
    }
    
    var canAdvance: Bool {
        switch currentStep {
        case .welcome:
            return true
        case .cableOrNFC:
            return true
        case .permissions:
            return audioPermissionGranted && networkPermissionGranted
        case .connecting:
            return appState.harnessConnectionState == .connected
        case .ready:
            return true
        }
    }
    
    func advanceStep() {
        withAnimation {
            switch currentStep {
            case .welcome:
                currentStep = .cableOrNFC
            case .cableOrNFC:
                currentStep = .permissions
            case .permissions:
                currentStep = .connecting
                appState.initializeSession()
            case .connecting:
                currentStep = .ready
            case .ready:
                // Will be dismissed by parent app
                break
            }
        }
    }
    
    func goBackStep() {
        withAnimation {
            switch currentStep {
            case .cableOrNFC:
                currentStep = .welcome
            case .permissions:
                currentStep = .cableOrNFC
            case .connecting:
                currentStep = .permissions
            case .ready:
                currentStep = .connecting
            default:
                break
            }
        }
    }
    
    func requestAudioPermission() {
        // Stub: real implementation would use AVAudioSession.requestRecordPermission
        audioPermissionGranted = true
    }
    
    func requestNetworkPermission() {
        // Stub: real implementation would prompt for Local Network permission
        networkPermissionGranted = true
    }
}

#Preview {
    LaunchView(appState: TubCompanionAppState())
}
